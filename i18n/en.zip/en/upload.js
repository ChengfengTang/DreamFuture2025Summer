export default {
  fileHashFail: 'Failed to get file hash, please try again!',
  sizeLimit: 'The file size exceeds the limit',
  uploadFailed: 'File upload failed',
  buttonText: 'Upload from computer',
  clickUpload: 'Click to upload',
  uploadDesc: 'Drag the file here, or ',
}