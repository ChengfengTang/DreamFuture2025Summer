export default {
  loadingText: 'Loading...',
  searchFileNotice: 'Search files by name',
  searchResource: 'Search by resource type',
  saveNetworkImage: 'Save network image',
  networkImageNotice: 'Please paste the network image URL',
  ok: 'OK',
}