export default {
    surname_name: 'Service Provider Name',
    money: 'Prepaid Amount',
    name: 'Recipient Account Name',
    type: 'Currency Type',
    account:'Recipient USDT Wallet Address',
    hash: 'Transaction Hash',
    img: 'Payment Voucher',
    status:'Status',
    remark:'Rejection Reason',
    pay_at:'Payment Time',
    created_at:'Creation Time',
  }
