export default {
    'loading:data': 'Loading data...',
    'view:photos': 'View photos',
    'recovery:successful': 'Recovery successful!',
    'delete:successfully': 'Deleted successfully!',
    'no:viewed': 'This image cannot be viewed',
    'no:pictures':'No pictures available',
    'delete:data':'Are you sure you want to delete this data?',
    'operation:successful':'Operation successful',
    'normal':'Normal',
    'disable':'Disabled',
    'restore_data':'Are you sure you want to restore this data?',
    'display_normal_data':'Display normal data',
    'display_recycle_bin_Data':'Display recycle bin data',
    'success':'Success'
  }