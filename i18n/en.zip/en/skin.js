export default {
  mine: 'Mine',
  businessGray: 'Business Gray',
  city: 'City',

  mineDesc: 'Predominantly pure white; Mine is the default skin',
  businessGrayDesc: 'Versatile and atmospheric gray, creating a businesslike and stable feel',
  cityDesc: 'May every corner of the city be filled with warmth',

  activated: 'Activated',
  use: 'Use',

  待审核: 'Pending Review',
  已打款: 'Paid',
  不通过: 'Rejected',

}