export default {
    请输入:'Please enter',
    请选择:'Please select',
    最小值:'Minimum value',
    最大值:'Maximum value',
    请选择开始时间:'Please select start time',
    请选择结束时间:'Please select end time',

    启用:'Enable',
    禁用:'Disable',
}
